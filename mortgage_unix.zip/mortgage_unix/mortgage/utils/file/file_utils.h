

#ifndef MORTGAGE_FILE_UTILS_H
#define MORTGAGE_FILE_UTILS_H

int fileExists(char filename []);

#endif //MORTGAGE_FILE_UTILS_H
