

#ifndef MORTGAGE_STRINGUTILS_H
#define MORTGAGE_STRINGUTILS_H

char** str_split(char* a_str, char a_delim);

int readString(char *string, int length);

void stringToLower(char *string);

#endif //MORTGAGE_STRINGUTILS_H
