1. Ouvrir Dev-C++
2. Fichier->Ouvrir Projet ou Fichier...
3. Localiser le répertoire mortgage_dev_c
4. Sélectionner le fichier mortgage.dev
5. Compiler (F9)
6. Exécuter (F10)