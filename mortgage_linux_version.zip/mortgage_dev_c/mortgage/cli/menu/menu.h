//
// Created by Roy on 12/02/2021.
//

#ifndef MORTGAGE_MENU_H
#define MORTGAGE_MENU_H

void run();

void exitMenu();

void grantCredit();

void printRemainingCapital();

void printCushioningRate();

void printMenuHeader();

int isNumberInList(int number, const int list[], int listSize);

#endif //MORTGAGE_MENU_H
