#Sur Windows avec l'IDE Dev-C++
1. Ouvrir Dev-C++
2. Fichier->Ouvrir Projet ou Fichier...
3. Localiser le répertoire mortgage_dev_c
4. Sélectionner le fichier mortgage.dev
5. Compiler (F9)
6. Exécuter (F10)

#Sur Linux
1. Ouvrir un terminal et se déplacer dans le répertoire /mortgage/bin.

2. Compilation des fichiers sources.
gcc -c ../boot/src/main.c ../cli/menu/menu.c ../core/client/client.c ../core/credit/credit.c ../infra/io/crud/client_crud.c ../infra/io/crud/credit_crud.c ../infra/io/parser.csv/csv.c ../utils/file/file_utils.c ../utils/strings/stringUtils.c ../utils/time/time_utils.c

3. Édition des liens
gcc -o mortgage ./main.o ./menu.o ./client.o ./credit.o ./client_crud.o ./credit_crud.o ./csv.o ./file_utils.o ./stringUtils.o ./time_utils.o

4. Lancer le programme.
./mortgage