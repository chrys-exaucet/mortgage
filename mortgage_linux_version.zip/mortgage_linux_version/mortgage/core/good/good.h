//
// Created by @chrys on 2/11/2021.
//

#ifndef MORTGAGE_GOOD_H
#define MORTGAGE_GOOD_H

typedef struct Good{
    char type[20];
    char *origin;
    unsigned int value;
    unsigned long cost;
}good_t;



#endif //MORTGAGE_GOOD_H
